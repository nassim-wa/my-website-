# FOR RAVERS asset notes

The product, community, and previous campaign placeholders were generated with the built-in image-generation tool. They are not documentary photographs, confirmed inventory, or other brands' campaign assets. The current personal campaign is documented separately below.

The original full-size WebP and four resized variants live in this folder. Keep matching front/back garment images when replacing designs.

## Prompts

Campaign: Intimate 35mm-style dawn editorial of three adult friends in oversized plain tees outside a concrete music venue; muted colors, human expressions, space for overlaid navigation and title; no third-party logos or text.

### waiting-front

Use case: product-mockup. A single premium fashion ecommerce product photograph. Full front view of one warm ivory oversized heavyweight cotton T-shirt, beautifully laid perfectly flat on a warm light gray #E9E7E2 seamless studio background. Centered, natural fabric creases, ribbed crew neck, boxy wide cut, dropped shoulder, short sleeves spread naturally, substantial cotton texture, subtle shadows beneath garment, entirely visible with ample margins. A very small dark red 'FOR RAVERS' wordmark on the left chest, otherwise plain. Soft daylight from top left. Photograph directly from above, photorealistic, portrait 4:5 ratio. No person, no hanger, no other objects, no props, no caption, no border, no watermark. Consistent minimalist independent luxury fashion catalog.

### waiting-back

Use case: product-mockup. A single premium fashion ecommerce product photograph. Full back view of one warm ivory oversized heavyweight cotton T-shirt, beautifully laid perfectly flat on a warm light gray #E9E7E2 seamless studio background. Centered, natural fabric creases, ribbed crew neck, boxy wide cut, dropped shoulder, short sleeves spread naturally, substantial cotton texture, subtle shadows beneath garment, entirely visible with ample margins. Small black lowercase Helvetica text centered on upper back in four lines, exactly: 'the music stops.' / 'sun is on.' / 'and suddenly,' / 'i’m waiting again.' Soft daylight from top left. Photograph directly from above, photorealistic, portrait 4:5 ratio. No person, no hanger, no other objects, no props, no caption, no border, no watermark. Consistent minimalist independent luxury fashion catalog.

### after-front

Use case: product-mockup. A single premium fashion ecommerce product photograph. Full front view of one washed charcoal black oversized heavyweight cotton T-shirt, beautifully laid perfectly flat on a warm light gray #E9E7E2 seamless studio background. Centered, natural fabric creases, ribbed crew neck, boxy wide cut, dropped shoulder, short sleeves spread naturally, substantial cotton texture, subtle shadows beneath garment, entirely visible with ample margins. A very small ivory 'FOR RAVERS' wordmark on the left chest, otherwise plain. Soft daylight from top left. Photograph directly from above, photorealistic, portrait 4:5 ratio. No person, no hanger, no other objects, no props, no caption, no border, no watermark. Consistent minimalist independent luxury fashion catalog.

### after-back

Use case: product-mockup. A single premium fashion ecommerce product photograph. Full back view of one washed charcoal black oversized heavyweight cotton T-shirt, beautifully laid perfectly flat on a warm light gray #E9E7E2 seamless studio background. Centered, natural fabric creases, ribbed crew neck, boxy wide cut, dropped shoulder, short sleeves spread naturally, substantial cotton texture, subtle shadows beneath garment, entirely visible with ample margins. Small ivory lowercase Helvetica text centered on upper back in two lines, exactly: 'one more track.' / 'one more memory.' Soft daylight from top left. Photograph directly from above, photorealistic, portrait 4:5 ratio. No person, no hanger, no other objects, no props, no caption, no border, no watermark. Consistent minimalist independent luxury fashion catalog.

### chapter-front

Use case: product-mockup. A single premium fashion ecommerce product photograph. Full front view of one muted light taupe stone oversized heavyweight cotton T-shirt, beautifully laid perfectly flat on a warm light gray #E9E7E2 seamless studio background. Centered, natural fabric creases, ribbed crew neck, boxy wide cut, dropped shoulder, short sleeves spread naturally, substantial cotton texture, subtle shadows beneath garment, entirely visible with ample margins. A very small dark red 'FOR RAVERS' wordmark on the left chest, otherwise plain. Soft daylight from top left. Photograph directly from above, photorealistic, portrait 4:5 ratio. No person, no hanger, no other objects, no props, no caption, no border, no watermark. Consistent minimalist independent luxury fashion catalog.

### chapter-back

Use case: product-mockup. A single premium fashion ecommerce product photograph. Full back view of one muted light taupe stone oversized heavyweight cotton T-shirt, beautifully laid perfectly flat on a warm light gray #E9E7E2 seamless studio background. Centered, natural fabric creases, ribbed crew neck, boxy wide cut, dropped shoulder, short sleeves spread naturally, substantial cotton texture, subtle shadows beneath garment, entirely visible with ample margins. Small black lowercase Helvetica text centered on upper back in two lines, exactly: 'see you' / 'in the next chapter.' Soft daylight from top left. Photograph directly from above, photorealistic, portrait 4:5 ratio. No person, no hanger, no other objects, no props, no caption, no border, no watermark. Consistent minimalist independent luxury fashion catalog.

### world-dawn

Use case: photorealistic-natural. Horizontal 3:2 cinematic 35mm film candid documentary photograph of four young adult friends in plain oversized black and ivory T-shirts sitting together on a low concrete wall above an empty beach at first light, seen from behind and slightly to side. Warm muted grey dawn, sea silver, one person rests head on friend's shoulder. Authentic human intimate memory, spontaneous fashion editorial without recognizable brands. Grain, soft sun, gentle imperfect framing, no text, no watermark, no festival props, no neon.

### world-night

Use case: photorealistic-natural. Vertical 4:5 candid 35mm film documentary fashion photograph from within an intimate small underground electronic music dance floor. Three young adult friends in plain oversized dark tees, one woman smiling with eyes closed, her arm gently lifted, a friend's shoulder in foreground, natural subtle motion blur. Dim warm amber light from a high window and muted red reflected on faces, dark natural skin tones, soft film grain. Real intimate human memory, no spectacular lights, no lasers, no neon, no logos, no text, no watermark.


## Current personal campaign

`campaign-personal.webp` and its responsive variants come from the exact user-selected file `ChatGPT Image Nov 13, 2026, 07_28_44 PM.png`. This is the user’s personal event photograph with an AI-edited black T-shirt print reading “I WAS HERE. I FELT IT.” and a small FOR RAVERS signature. Only responsive resizing and WebP compression were applied during website integration. The original `campaign.webp` concept remains available separately.

`campaign-personal-wide.webp` is an AI-outpainted 16:9 adaptation of that selected portrait for desktop. The surrounding festival, grass and sky were extended to the left so the scene fills the screen with a wider composition. Mobile retains the selected portrait. The full PNG is delivered as `outputs/for-ravers-personal-campaign-landscape-v1.png` in the workspace.


## Personal Our World photograph

`world-personal.webp` and four responsive variants replace the second (right) editorial image. Source: the user-supplied `IMG_1187.HEIC`, converted with macOS sips and resized to WebP. No AI editing was applied. The same photo appears on Our World through the shared brand data; the original left-hand scene remains available as `world-dawn.webp`.


## Left-hand Our World photo — 18 November 2026

`world-crowd.webp` and four responsive variants replace the first (left) editorial image, using the user-supplied `photo web.png`. Only resizing and WebP compression were applied. The right-hand image remains `world-personal.webp`. Shared brand data also updates the wide image on the Our World page.
